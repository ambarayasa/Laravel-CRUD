

<?php $__env->startSection('title', 'Daftar Golongan Darah'); ?>

<?php $__env->startSection('container'); ?>

      <div class="container">
          <div class="row">
              <div class="col-10">
              <h1 class="mt-3">List Golongan Darah</h1>
              
              <a href="/golongandarah/create" class="btn btn-outline-primary">+New Data</a>
              <?php if(session('status')): ?>
                 <div class="alert alert-success">
                 <?php echo e(session('status')); ?>

                </div>
                    <?php endif; ?>
              <table class="table">
                <thead class="thead-dark">
                   <tr>
                   <th scope="col">No</th> 
                   <th scope="col">Golongan Darah</th> 
                   <th scope="col">Rhesus</th>
                   <th scope="col">Action</th> 
                   </tr>
                </thead>
                 <tbody>
                  <?php $__currentLoopData = $goldar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gdar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <tr>
                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                    <td><?php echo e($gdar-> golongandarah); ?></td>
                    <td><?php echo e($gdar-> rhesus); ?></td>
                    <td>
                    
                    <a href="/golongandarah/<?php echo e($gdar->id); ?>/edit" class="btn btn-primary">Edit</a>

                    <form action="/golongandarah/<?php echo e($gdar->id); ?>" method="post" class="d-inline">
                      
                      <?php echo csrf_field(); ?>
                      <?php echo e(method_field('DELETE')); ?>

                      <button type="submit" class="btn btn-danger">Delete</button>
                    </form>
                    <!-- <a href="" class="badge badge-success ">edit</a>
                    <a href="" class="badge badge-danger">delete</a> -->
                    </td>
                 </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>


          </div>
      </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel bootstrap\prognetcrud\resources\views/golongandarah/index.blade.php ENDPATH**/ ?>