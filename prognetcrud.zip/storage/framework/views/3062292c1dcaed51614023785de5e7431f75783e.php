

<?php $__env->startSection('title', 'Edit Data'); ?>

<?php $__env->startSection('container'); ?>

      <div class="container">
          <div class="row">
              <div class="col-8">
              <h1 class="mt-3">Edit Hobby</h1>

<form method="post" action="/hobby/<?php echo e($hby->id); ?>">
    <?php echo csrf_field(); ?>
    <?php echo e(method_field('PUT')); ?>

    <div class="form-group">
        <label for="hobby">Hobby</label>
        <input type="text" class="form-control" id="hobby" name="hobby" value="<?php echo e($hby->hobby); ?>">
    </div>

    <button type="submit" class="btn btn-primary">Simpan</button>
    <button type="button" class="btn btn-primary" onclick="location.href='/hobby'">Kembali</button>



</form>


          </div>
      </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel bootstrap\prognetcrud\resources\views/hobby/edit.blade.php ENDPATH**/ ?>