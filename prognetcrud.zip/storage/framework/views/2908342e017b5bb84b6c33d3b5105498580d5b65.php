

<?php $__env->startSection('title', 'Edit Data'); ?>

<?php $__env->startSection('container'); ?>

      <div class="container">
          <div class="row">
              <div class="col-8">
              <h1 class="mt-3">Edit Kontak</h1>

<form method="post" action="/mahasiswa/<?php echo e($mhs->id); ?>">
    <?php echo csrf_field(); ?>
    <?php echo e(method_field('PUT')); ?>

    <div class="form-group">
        <label for="nama">Nama</label>
        <input type="text" class="form-control" id="nama" name="nama" value="<?php echo e($mhs->nama); ?>">
    </div>

    <div class="form-group">
        <label for="alamat">Alamat</label>
        <input type="text" class="form-control" id="alamat" name="alamat" value="<?php echo e($mhs->alamat); ?>">
    </div>

    <div class="form-group">
        <label for="telepon">Telepon</label>
        <input type="text" class="form-control" id="telepon" name="telepon" value="<?php echo e($mhs->telepon); ?>">
    </div>

    <div class="form-group">
        <label for="darahid">Golongan Darah</label>
        <select selected="<?php echo e($mhs->darahid); ?>" class="form-control" id="darahid" name="darahid">
        <?php $__currentLoopData = $blood; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($gd->id); ?>" <?php if($gd->id==$mhs->darahid): ?>
        SELECTED
        <?php endif; ?>>
        <?php echo e($gd->golongandarah); ?>

        </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <label for="hobby" class="form-label">Hobby</label>
    <?php $__currentLoopData = $hobby; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="form-check">
            <input class="form-check-input" type="checkbox" value="<?php echo e($item->id); ?>" name="hobby[]"
            <?php if(in_array($item->id, $khobby)): ?>
                CHECKED
            <?php endif; ?>
            >

            <label class="form-check-label" for="flexCheckDefault">
                <?php echo e($item->hobby); ?>

            </label>
    </div>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <div class="form-group">
        <label for="email">Email</label>
        <input type="text" class="form-control" id="email" name="email" value="<?php echo e($mhs->email); ?>">
    </div>
    <button type="submit" class="btn btn-primary">Simpan</button>
    <button type="button" class="btn btn-primary" onclick="location.href='/mahasiswa'">Kembali</button>

</form>


          </div>
      </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel bootstrap\prognetcrud\resources\views/mahasiswa/edit.blade.php ENDPATH**/ ?>