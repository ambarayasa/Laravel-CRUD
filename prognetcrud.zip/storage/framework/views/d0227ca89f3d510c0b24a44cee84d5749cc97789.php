

<?php $__env->startSection('title', 'Tambah Data'); ?>

<?php $__env->startSection('container'); ?>

      <div class="container">
          <div class="row">
              <div class="col-8">
              <h1 class="mt-3">Tambah Data</h1>

<form method="post" action="/kontakhobby">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label for="idkontak">ID Kontak</label>
        <input type="text" class="form-control" id="idkontak" placeholder="Masukkan ID Kontak" name="idkontak" required>
    </div>
    <div class="form-group">
        <label for="idhobby">ID Hobby</label>
        <input type="text" class="form-control" id="idhobby" placeholder="Masukkan ID Hobby" name="idhobby" required>
    </div>
    <button type="submit" class="btn btn-primary">Simpan</button>
    <button type="button" class="btn btn-primary" onclick="location.href='/kontakhobby'">Kembali</button>

</form>


          </div>
      </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel bootstrap\prognetcrud\resources\views/kontakhobby/create.blade.php ENDPATH**/ ?>