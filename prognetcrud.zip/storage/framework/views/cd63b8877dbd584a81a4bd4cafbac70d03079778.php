

<?php $__env->startSection('title', 'Edit Data'); ?>

<?php $__env->startSection('container'); ?>

      <div class="container">
          <div class="row">
              <div class="col-8">
              <h1 class="mt-3">Edit Data</h1>

<form method="post" action="/mahasiswa/<?php echo e($mhs->id); ?>">
    <?php echo csrf_field(); ?>
    <?php echo e(method_field('PUT')); ?>

    <div class="form-group">
        <label for="nama">Nama</label>
        <input type="text" class="form-control" id="nama" name="nama" value="<?php echo e($mhs->nama); ?>">
    </div>

    <div class="form-group">
        <label for="alamat">Alamat</label>
        <input type="text" class="form-control" id="alamat" name="alamat" value="<?php echo e($mhs->alamat); ?>">
    </div>

    <div class="form-group">
        <label for="telepon">Telepon</label>
        <input type="text" class="form-control" id="telepon" name="telepon" value="<?php echo e($mhs->telepon); ?>">
    </div>

    <div class="form-group">
        <label for="iddarah">ID Darah</label>
        <input type="text" class="form-control" id="iddarah" name="iddarah" value="<?php echo e($mhs->darahid); ?>">
    </div>

    <div class="form-group">
        <label for="email">Email</label>
        <input type="text" class="form-control" id="email" name="email" value="<?php echo e($mhs->email); ?>">
    </div>
    <button type="submit" class="btn btn-primary">Edit Data!</button>

</form>


          </div>
      </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prognetcrud\resources\views/mahasiswa/edit.blade.php ENDPATH**/ ?>