

<?php $__env->startSection('title', 'Edit Data'); ?>

<?php $__env->startSection('container'); ?>

      <div class="container">
          <div class="row">
              <div class="col-8">
              <h1 class="mt-3">Edit Data</h1>

<form method="post" action="/kontakhobby/<?php echo e($khby->id); ?>">
    <?php echo csrf_field(); ?>
    <?php echo e(method_field('PUT')); ?>

    <div class="form-group">
        <label for="idkontak">ID Kontak</label>
        <input type="text" class="form-control" id="idkontak" name="idkontak" value="<?php echo e($khby->idkontak); ?>">
    </div>

    <div class="form-group">
        <label for="idhobby">ID Hobby</label>
        <input type="text" class="form-control" id="idhobby" name="idhobby" value="<?php echo e($khby->idhobby); ?>">
    </div>

    <button type="submit" class="btn btn-primary">Edit Data!</button>

</form>


          </div>
      </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel bootstrap\prognetcrud\resources\views/kontakhobby/edit.blade.php ENDPATH**/ ?>