@extends('layout/main')

@section('title', 'Selamat Datang')

@section('container')

      <div class="container">
          <div class="row">
              <div class="col-10">
              <h1 class="mt-3">HALLO, SELAMAT DATANG DI WEB INI :) </h1>
              <h1 class="mt-3">JANGAN LUPA BAHAGIA:) </h1>
              <h1 class="mt-3">JANGAN LUPA MENGGUNAKAN MASKER :) </h1>
          </div>
      </div>
  </div>
@endsection
